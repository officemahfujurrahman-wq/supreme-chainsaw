# Mallik MessMate — Hostel Meal & Balance Tracker

Static PWA built from Stitch design mockups. Deployed on Cloudflare Workers (Static Assets).

## Routes
- `/` — Dashboard (balance breakdown, recent meals & payments)
- `/meals.html` — Daily meal registry
- `/meal-rate.html` — Meal rate configuration
- `/payments.html` — Payments log

## Deploy
This project has **no build step**. Static HTML/CSS only.

**Build command:** *(empty)*
**Deploy command:** `npx wrangler deploy`
**Root directory:** `/` (project root)
**Build output directory:** `./` (configured in `wrangler.jsonc`)

## Files
- `index.html`, `meals.html`, `meal-rate.html`, `payments.html` — pages
- `icons/` — PWA icons (16/32/180/192/512) + maskable + logo
- `manifest.json` — PWA manifest
- `sw.js` — service worker (offline cache)
- `wrangler.jsonc` — Cloudflare Workers config
